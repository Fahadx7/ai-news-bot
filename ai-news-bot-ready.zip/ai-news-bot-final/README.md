# 🤖 بوت أخبار الذكاء الاصطناعي

يجلب أهم أخبار AI يومياً ويرسلها لك بالعربي على تلجرام.

---

## الإعداد — 4 خطوات

### 1️⃣ إنشاء بوت تلجرام
1. افتح تلجرام وابحث عن **@BotFather**
2. أرسل `/newbot`
3. اختر اسم للبوت (مثلاً: AI News Bot)
4. احفظ الـ **Token** اللي يعطيك إياه

### 2️⃣ احصل على Chat ID
1. ابحث عن **@userinfobot** في تلجرام
2. أرسل له `/start`
3. يعطيك الـ **Chat ID** — احفظه

### 3️⃣ إعداد المتغيرات
انسخ `.env.example` لـ `.env` وأضف:
```
TELEGRAM_TOKEN=توكن_البوت
TELEGRAM_CHAT_ID=آيدي_شاتك  
ANTHROPIC_API_KEY=مفتاح_كلود_من_console.anthropic.com
```

### 4️⃣ رفع على Railway (مجاني)
1. اذهب لـ railway.app وسجّل بـ GitHub
2. "New Project" → "Deploy from GitHub"
3. ارفع هذا المجلد
4. أضف المتغيرات في Settings → Variables
5. البوت يشتغل كل يوم 10 صباح بتوقيت الرياض ✅

---

## تخصيص البوت

في `bot.py` تقدر تعدّل:
- `NEWS_COUNT` — عدد الأخبار (الافتراضي 7)
- `RSS_FEEDS` — أضف أو احذف مصادر
- `cronSchedule` في `railway.toml` — وقت الإرسال

---

## المصادر الافتراضية
- Anthropic Blog
- OpenAI Blog  
- Google DeepMind
- The Verge AI
- TechCrunch AI
- MIT Technology Review
- VentureBeat AI
